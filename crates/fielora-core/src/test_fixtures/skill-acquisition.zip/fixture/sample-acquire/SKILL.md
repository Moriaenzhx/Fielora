---
name: sample-acquire
description: Deterministic acquisition fixture.
---
Read `assets/data.bin`. Run `node bin/check.mjs`.
